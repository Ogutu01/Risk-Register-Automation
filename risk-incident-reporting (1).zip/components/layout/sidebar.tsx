"use client"

import { useState } from "react"
import { BarChart3, FileText, Settings, Shield, Users, AlertTriangle, Home, LogOut, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import type { User } from "../../lib/auth"

interface SidebarProps {
  user: User
  currentPage: string
  onPageChange: (page: string) => void
  onLogout: () => void
}

export function Sidebar({ user, currentPage, onPageChange, onLogout }: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false)

  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: Home, roles: ["staff", "risk_compliance", "risk_owner"] },
    { id: "report-incident", label: "Report Incident", icon: AlertTriangle, roles: ["staff", "risk_compliance"] },
    { id: "incidents", label: "Risk Incidents", icon: FileText, roles: ["risk_compliance", "risk_owner"] },
    { id: "risk-parameters", label: "Risk Parameters", icon: Settings, roles: ["risk_compliance"] },
    { id: "reports", label: "Reports", icon: BarChart3, roles: ["risk_compliance", "risk_owner"] },
    { id: "users", label: "User Management", icon: Users, roles: ["risk_compliance"] },
  ]

  const filteredMenuItems = menuItems.filter((item) => item.roles.includes(user.role))

  return (
    <div
      className={cn(
        "bg-white border-r border-gray-200 flex flex-col transition-all duration-300",
        isCollapsed ? "w-16" : "w-64",
      )}
    >
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          {!isCollapsed && (
            <div className="flex items-center">
              <Shield className="h-6 w-6 text-red-600 mr-2" />
              <span className="font-semibold text-gray-900">Risk Register</span>
            </div>
          )}
          <Button variant="ghost" size="sm" onClick={() => setIsCollapsed(!isCollapsed)}>
            {isCollapsed ? <Menu className="h-4 w-4" /> : <X className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      <nav className="flex-1 p-4">
        <div className="space-y-2">
          {filteredMenuItems.map((item) => {
            const Icon = item.icon
            return (
              <Button
                key={item.id}
                variant={currentPage === item.id ? "default" : "ghost"}
                className={cn("w-full justify-start", isCollapsed && "px-2")}
                onClick={() => onPageChange(item.id)}
              >
                <Icon className={cn("h-4 w-4", !isCollapsed && "mr-2")} />
                {!isCollapsed && item.label}
              </Button>
            )
          })}
        </div>
      </nav>

      <div className="p-4 border-t border-gray-200">
        {!isCollapsed && (
          <div className="mb-4">
            <p className="text-sm font-medium text-gray-900">{user.name}</p>
            <p className="text-xs text-gray-500">{user.role.replace("_", " ").toUpperCase()}</p>
            <p className="text-xs text-gray-500">{user.department}</p>
          </div>
        )}
        <Button
          variant="ghost"
          className={cn("w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50", isCollapsed && "px-2")}
          onClick={onLogout}
        >
          <LogOut className={cn("h-4 w-4", !isCollapsed && "mr-2")} />
          {!isCollapsed && "Logout"}
        </Button>
      </div>
    </div>
  )
}
