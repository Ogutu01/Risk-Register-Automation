"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { AlertTriangle, Clock, BarChart3 } from "lucide-react"
import type { User } from "../../lib/auth"

interface DashboardProps {
  user: User
}

export function Dashboard({ user }: DashboardProps) {
  // Mock dashboard data - replace with real data
  const metrics = {
    totalIncidents: 156,
    openIncidents: 23,
    criticalIncidents: 5,
    resolvedThisMonth: 18,
    averageResolutionTime: 4.2,
    riskTrends: [
      { month: "Jan", incidents: 12 },
      { month: "Feb", incidents: 15 },
      { month: "Mar", incidents: 18 },
      { month: "Apr", incidents: 14 },
      { month: "May", incidents: 20 },
      { month: "Jun", incidents: 16 },
    ],
    severityDistribution: [
      { severity: "Critical", count: 5, color: "bg-red-500" },
      { severity: "High", count: 12, color: "bg-orange-500" },
      { severity: "Medium", count: 28, color: "bg-yellow-500" },
      { severity: "Low", count: 35, color: "bg-green-500" },
    ],
    departmentBreakdown: [
      { department: "Airtel Money Operations", count: 45 },
      { department: "Technology", count: 32 },
      { department: "Customer Service", count: 28 },
      { department: "Finance", count: 18 },
      { department: "Security", count: 15 },
    ],
  }

  const recentIncidents = [
    {
      id: "1",
      title: "Payment Gateway Timeout",
      severity: "high",
      department: "Technology",
      reportedDate: "2024-01-15",
      status: "investigating",
    },
    {
      id: "2",
      title: "Customer Data Access Issue",
      severity: "critical",
      department: "Security",
      reportedDate: "2024-01-14",
      status: "open",
    },
    {
      id: "3",
      title: "Transaction Processing Delay",
      severity: "medium",
      department: "Operations",
      reportedDate: "2024-01-13",
      status: "resolved",
    },
  ]

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-100 text-red-800"
      case "high":
        return "bg-orange-100 text-orange-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open":
        return "bg-red-100 text-red-800"
      case "investigating":
        return "bg-blue-100 text-blue-800"
      case "resolved":
        return "bg-green-100 text-green-800"
      case "closed":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Risk Dashboard</h1>
        <p className="text-gray-600">Welcome back, {user.name}</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Incidents</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.totalIncidents}</div>
            <p className="text-xs text-muted-foreground">+12% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Open Incidents</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{metrics.openIncidents}</div>
            <p className="text-xs text-muted-foreground">Requires attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical Incidents</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{metrics.criticalIncidents}</div>
            <p className="text-xs text-muted-foreground">Immediate action needed</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Resolution Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.averageResolutionTime} days</div>
            <p className="text-xs text-muted-foreground">-0.5 days from last month</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Risk Severity Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Risk Severity Distribution</CardTitle>
            <CardDescription>Current breakdown of incidents by severity level</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {metrics.severityDistribution.map((item) => (
              <div key={item.severity} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${item.color}`} />
                  <span className="text-sm font-medium">{item.severity}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-600">{item.count}</span>
                  <div className="w-20 bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${item.color}`}
                      style={{ width: `${(item.count / 80) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Recent Incidents */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Incidents</CardTitle>
            <CardDescription>Latest risk incidents reported</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentIncidents.map((incident) => (
                <div key={incident.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <h4 className="text-sm font-medium">{incident.title}</h4>
                    <p className="text-xs text-gray-500">
                      {incident.department} • {incident.reportedDate}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className={getSeverityColor(incident.severity)}>{incident.severity}</Badge>
                    <Badge className={getStatusColor(incident.status)}>{incident.status}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Department Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Incidents by Department</CardTitle>
          <CardDescription>Risk incident distribution across departments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {metrics.departmentBreakdown.map((dept) => (
              <div key={dept.department} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium">{dept.department}</h4>
                  <span className="text-lg font-bold">{dept.count}</span>
                </div>
                <Progress value={(dept.count / 50) * 100} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
