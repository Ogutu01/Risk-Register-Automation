"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertTriangle, FileText, MapPin, Calculator } from "lucide-react"
import type { User as UserType } from "../../lib/auth"

interface IncidentFormProps {
  user: UserType
  onSubmit: (data: any) => void
}

export function IncidentForm({ user, onSubmit }: IncidentFormProps) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    severity: "",
    location: "",
    department: user.department,
    dateOccurred: "",
    timeOccurred: "",
    likelihood: 1,
    impact: 1,
    immediateActions: "",
    potentialImpact: "",
    witnessesPresent: false,
    witnessDetails: "",
    attachments: [] as File[],
  })

  const handleInputChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const calculateRiskScore = () => {
    return formData.likelihood * formData.impact
  }

  const getRiskLevel = (score: number) => {
    if (score >= 20) return { level: "Critical", color: "bg-red-100 text-red-800" }
    if (score >= 15) return { level: "High", color: "bg-orange-100 text-orange-800" }
    if (score >= 10) return { level: "Medium", color: "bg-yellow-100 text-yellow-800" }
    return { level: "Low", color: "bg-green-100 text-green-800" }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const riskScore = calculateRiskScore()
    const submissionData = {
      ...formData,
      riskScore,
      reportedBy: user.name,
      reportedDate: new Date().toISOString().split("T")[0],
      status: "open",
    }
    onSubmit(submissionData)
  }

  const riskScore = calculateRiskScore()
  const riskLevel = getRiskLevel(riskScore)

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Report Risk Incident</h1>
          <p className="text-gray-600">
            Report safety incidents, operational risks, and compliance issues for Airtel Money operations
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Risk Classification */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Risk Classification
              </CardTitle>
              <CardDescription>Categorize and assess the risk incident</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="category">Risk Category *</Label>
                  <Select value={formData.category} onValueChange={(value) => handleInputChange("category", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select risk category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="operational">Operational Risk</SelectItem>
                      <SelectItem value="financial">Financial Risk</SelectItem>
                      <SelectItem value="compliance">Compliance Risk</SelectItem>
                      <SelectItem value="technology">Technology Risk</SelectItem>
                      <SelectItem value="security">Security Risk</SelectItem>
                      <SelectItem value="fraud">Fraud Risk</SelectItem>
                      <SelectItem value="reputational">Reputational Risk</SelectItem>
                      <SelectItem value="regulatory">Regulatory Risk</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="department">Department *</Label>
                  <Select value={formData.department} onValueChange={(value) => handleInputChange("department", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Airtel Money Operations">Airtel Money Operations</SelectItem>
                      <SelectItem value="Technology">Technology</SelectItem>
                      <SelectItem value="Customer Service">Customer Service</SelectItem>
                      <SelectItem value="Finance">Finance</SelectItem>
                      <SelectItem value="Risk & Compliance">Risk & Compliance</SelectItem>
                      <SelectItem value="Security">Security</SelectItem>
                      <SelectItem value="Legal">Legal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="title">Incident Title *</Label>
                <Input
                  id="title"
                  placeholder="Brief description of the risk incident"
                  value={formData.title}
                  onChange={(e) => handleInputChange("title", e.target.value)}
                  required
                />
              </div>
            </CardContent>
          </Card>

          {/* Risk Assessment Engine */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calculator className="h-5 w-5 mr-2" />
                Risk Assessment
              </CardTitle>
              <CardDescription>Assess the likelihood and impact to calculate risk score</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <Label>Likelihood (1-5) *</Label>
                  <RadioGroup
                    value={formData.likelihood.toString()}
                    onValueChange={(value) => handleInputChange("likelihood", Number.parseInt(value))}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="1" id="likelihood-1" />
                      <Label htmlFor="likelihood-1">1 - Very Unlikely</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="2" id="likelihood-2" />
                      <Label htmlFor="likelihood-2">2 - Unlikely</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="3" id="likelihood-3" />
                      <Label htmlFor="likelihood-3">3 - Possible</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="4" id="likelihood-4" />
                      <Label htmlFor="likelihood-4">4 - Likely</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="5" id="likelihood-5" />
                      <Label htmlFor="likelihood-5">5 - Very Likely</Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="space-y-4">
                  <Label>Impact (1-5) *</Label>
                  <RadioGroup
                    value={formData.impact.toString()}
                    onValueChange={(value) => handleInputChange("impact", Number.parseInt(value))}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="1" id="impact-1" />
                      <Label htmlFor="impact-1">1 - Negligible</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="2" id="impact-2" />
                      <Label htmlFor="impact-2">2 - Minor</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="3" id="impact-3" />
                      <Label htmlFor="impact-3">3 - Moderate</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="4" id="impact-4" />
                      <Label htmlFor="impact-4">4 - Major</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="5" id="impact-5" />
                      <Label htmlFor="impact-5">5 - Catastrophic</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Calculated Risk Score</h4>
                    <p className="text-sm text-gray-600">Likelihood × Impact = Risk Score</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold">{riskScore}</div>
                    <Badge className={riskLevel.color}>{riskLevel.level}</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Incident Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MapPin className="h-5 w-5 mr-2" />
                Incident Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="location">Location *</Label>
                  <Input
                    id="location"
                    placeholder="Building, office, or system location"
                    value={formData.location}
                    onChange={(e) => handleInputChange("location", e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="date-occurred">Date Occurred *</Label>
                  <Input
                    id="date-occurred"
                    type="date"
                    value={formData.dateOccurred}
                    onChange={(e) => handleInputChange("dateOccurred", e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Detailed Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Provide a comprehensive description of the risk incident, including what happened, when, and any contributing factors..."
                  className="min-h-32"
                  value={formData.description}
                  onChange={(e) => handleInputChange("description", e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="immediate-actions">Immediate Actions Taken</Label>
                <Textarea
                  id="immediate-actions"
                  placeholder="Describe any immediate actions taken to mitigate the risk..."
                  value={formData.immediateActions}
                  onChange={(e) => handleInputChange("immediateActions", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="potential-impact">Potential Business Impact</Label>
                <Textarea
                  id="potential-impact"
                  placeholder="Describe potential impacts on Airtel Money operations, customers, or business..."
                  value={formData.potentialImpact}
                  onChange={(e) => handleInputChange("potentialImpact", e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Important:</strong> This report will be reviewed by the Risk & Compliance team. For critical
              incidents requiring immediate attention, please also contact the Risk Management team directly.
            </AlertDescription>
          </Alert>

          <div className="flex justify-end space-x-4">
            <Button type="button" variant="outline">
              Save as Draft
            </Button>
            <Button type="submit" className="bg-red-600 hover:bg-red-700">
              Submit Risk Report
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
