"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Search, MessageSquare, Eye, Filter } from "lucide-react"
import type { User, RiskIncident } from "../../lib/auth"

interface IncidentListProps {
  user: User
}

export function IncidentList({ user }: IncidentListProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterSeverity, setFilterSeverity] = useState("all")
  const [selectedIncident, setSelectedIncident] = useState<RiskIncident | null>(null)
  const [newComment, setNewComment] = useState("")

  // Mock data - replace with real data
  const incidents: RiskIncident[] = [
    {
      id: "1",
      title: "Payment Gateway Timeout Issues",
      description: "Multiple customers reporting payment timeouts during peak hours",
      category: "technology",
      severity: "high",
      status: "investigating",
      reportedBy: "John Doe",
      reportedDate: "2024-01-15",
      location: "Payment Processing System",
      department: "Technology",
      riskOwner: "Mike Johnson",
      riskScore: 16,
      likelihood: 4,
      impact: 4,
      comments: [
        {
          id: "1",
          userId: "2",
          userName: "Jane Smith",
          content: "Investigating the root cause. Initial analysis suggests database connection issues.",
          timestamp: "2024-01-15T10:30:00Z",
        },
      ],
      attachments: [],
    },
    {
      id: "2",
      title: "Customer Data Access Breach Attempt",
      description: "Suspicious login attempts detected on customer service portal",
      category: "security",
      severity: "critical",
      status: "open",
      reportedBy: "Sarah Wilson",
      reportedDate: "2024-01-14",
      location: "Customer Service Portal",
      department: "Security",
      riskOwner: "Mike Johnson",
      riskScore: 20,
      likelihood: 4,
      impact: 5,
      comments: [],
      attachments: [],
    },
  ]

  const filteredIncidents = incidents.filter((incident) => {
    const matchesSearch =
      incident.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      incident.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = filterStatus === "all" || incident.status === filterStatus
    const matchesSeverity = filterSeverity === "all" || incident.severity === filterSeverity

    return matchesSearch && matchesStatus && matchesSeverity
  })

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-100 text-red-800"
      case "high":
        return "bg-orange-100 text-orange-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open":
        return "bg-red-100 text-red-800"
      case "investigating":
        return "bg-blue-100 text-blue-800"
      case "resolved":
        return "bg-green-100 text-green-800"
      case "closed":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const handleAddComment = () => {
    if (newComment.trim() && selectedIncident) {
      // Add comment logic here
      setNewComment("")
    }
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Risk Incidents</h1>
        <p className="text-gray-600">Monitor and manage risk incidents across Airtel Money operations</p>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Filter className="h-5 w-5 mr-2" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Search</Label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Search incidents..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="investigating">Investigating</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Severity</Label>
              <Select value={filterSeverity} onValueChange={setFilterSeverity}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severity</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Incidents List */}
      <div className="space-y-4">
        {filteredIncidents.map((incident) => (
          <Card key={incident.id}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <h3 className="text-lg font-semibold">{incident.title}</h3>
                    <Badge className={getSeverityColor(incident.severity)}>{incident.severity}</Badge>
                    <Badge className={getStatusColor(incident.status)}>{incident.status}</Badge>
                  </div>
                  <p className="text-gray-600 mb-3">{incident.description}</p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-500">
                    <div>
                      <span className="font-medium">Risk Score:</span> {incident.riskScore}
                    </div>
                    <div>
                      <span className="font-medium">Department:</span> {incident.department}
                    </div>
                    <div>
                      <span className="font-medium">Reported by:</span> {incident.reportedBy}
                    </div>
                    <div>
                      <span className="font-medium">Date:</span> {incident.reportedDate}
                    </div>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setSelectedIncident(incident)}>
                        <Eye className="h-4 w-4 mr-1" />
                        View
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>{incident.title}</DialogTitle>
                        <DialogDescription>Risk Incident Details and Comments</DialogDescription>
                      </DialogHeader>
                      {selectedIncident && (
                        <div className="space-y-6">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label className="font-medium">Category</Label>
                              <p className="capitalize">{selectedIncident.category}</p>
                            </div>
                            <div>
                              <Label className="font-medium">Risk Score</Label>
                              <p>
                                {selectedIncident.riskScore} (L:{selectedIncident.likelihood} × I:
                                {selectedIncident.impact})
                              </p>
                            </div>
                            <div>
                              <Label className="font-medium">Location</Label>
                              <p>{selectedIncident.location}</p>
                            </div>
                            <div>
                              <Label className="font-medium">Risk Owner</Label>
                              <p>{selectedIncident.riskOwner}</p>
                            </div>
                          </div>

                          <div>
                            <Label className="font-medium">Description</Label>
                            <p className="mt-1">{selectedIncident.description}</p>
                          </div>

                          <div>
                            <Label className="font-medium">Comments ({selectedIncident.comments.length})</Label>
                            <div className="space-y-3 mt-2">
                              {selectedIncident.comments.map((comment) => (
                                <div key={comment.id} className="border rounded-lg p-3">
                                  <div className="flex items-center justify-between mb-2">
                                    <span className="font-medium text-sm">{comment.userName}</span>
                                    <span className="text-xs text-gray-500">
                                      {new Date(comment.timestamp).toLocaleString()}
                                    </span>
                                  </div>
                                  <p className="text-sm">{comment.content}</p>
                                </div>
                              ))}
                            </div>

                            {user.permissions.includes("comment_incidents") && (
                              <div className="mt-4 space-y-2">
                                <Textarea
                                  placeholder="Add a comment..."
                                  value={newComment}
                                  onChange={(e) => setNewComment(e.target.value)}
                                />
                                <Button onClick={handleAddComment} size="sm">
                                  <MessageSquare className="h-4 w-4 mr-1" />
                                  Add Comment
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredIncidents.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-gray-500">No incidents found matching your criteria.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
