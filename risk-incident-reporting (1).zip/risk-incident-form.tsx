"use client"

import type React from "react"

import { useState } from "react"
import { Upload, AlertTriangle, FileText, User, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function RiskIncidentReportingInterface() {
  const [formData, setFormData] = useState({
    incidentType: "",
    severity: "",
    title: "",
    description: "",
    location: "",
    department: "",
    dateOccurred: "",
    timeOccurred: "",
    reporterName: "",
    reporterEmail: "",
    reporterPhone: "",
    witnessesPresent: false,
    witnessDetails: "",
    immediateActions: "",
    potentialImpact: "",
    attachments: [] as File[],
  })

  const handleInputChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    setFormData((prev) => ({ ...prev, attachments: [...prev.attachments, ...files] }))
  }

  const removeFile = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      attachments: prev.attachments.filter((_, i) => i !== index),
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
    // Handle form submission here
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-100 text-red-800 border-red-200"
      case "high":
        return "bg-orange-100 text-orange-800 border-orange-200"
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "low":
        return "bg-green-100 text-green-800 border-green-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center mb-4">
            <AlertTriangle className="h-8 w-8 text-red-600 mr-2" />
            <h1 className="text-3xl font-bold text-gray-900">Risk Incident Reporting</h1>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Report safety incidents, near misses, hazards, and other risk-related events to help maintain a safe
            workplace environment.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Incident Classification */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Incident Classification
              </CardTitle>
              <CardDescription>Categorize and prioritize the incident</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="incident-type">Incident Type *</Label>
                  <Select
                    value={formData.incidentType}
                    onValueChange={(value) => handleInputChange("incidentType", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select incident type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="workplace-injury">Workplace Injury</SelectItem>
                      <SelectItem value="near-miss">Near Miss</SelectItem>
                      <SelectItem value="property-damage">Property Damage</SelectItem>
                      <SelectItem value="environmental">Environmental Incident</SelectItem>
                      <SelectItem value="security-breach">Security Breach</SelectItem>
                      <SelectItem value="equipment-failure">Equipment Failure</SelectItem>
                      <SelectItem value="fire-emergency">Fire/Emergency</SelectItem>
                      <SelectItem value="chemical-spill">Chemical Spill</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Severity Level *</Label>
                  <RadioGroup
                    value={formData.severity}
                    onValueChange={(value) => handleInputChange("severity", value)}
                    className="flex flex-wrap gap-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="critical" id="critical" />
                      <Label htmlFor="critical">
                        <Badge className={getSeverityColor("critical")}>Critical</Badge>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="high" id="high" />
                      <Label htmlFor="high">
                        <Badge className={getSeverityColor("high")}>High</Badge>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="medium" id="medium" />
                      <Label htmlFor="medium">
                        <Badge className={getSeverityColor("medium")}>Medium</Badge>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="low" id="low" />
                      <Label htmlFor="low">
                        <Badge className={getSeverityColor("low")}>Low</Badge>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="title">Incident Title *</Label>
                <Input
                  id="title"
                  placeholder="Brief description of the incident"
                  value={formData.title}
                  onChange={(e) => handleInputChange("title", e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Incident Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MapPin className="h-5 w-5 mr-2" />
                Incident Details
              </CardTitle>
              <CardDescription>Provide detailed information about what happened</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="location">Location *</Label>
                  <Input
                    id="location"
                    placeholder="Building, floor, room, or area"
                    value={formData.location}
                    onChange={(e) => handleInputChange("location", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="department">Department/Division</Label>
                  <Select value={formData.department} onValueChange={(value) => handleInputChange("department", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="operations">Operations</SelectItem>
                      <SelectItem value="manufacturing">Manufacturing</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                      <SelectItem value="warehouse">Warehouse</SelectItem>
                      <SelectItem value="office">Office</SelectItem>
                      <SelectItem value="laboratory">Laboratory</SelectItem>
                      <SelectItem value="security">Security</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="date-occurred">Date Occurred *</Label>
                  <Input
                    id="date-occurred"
                    type="date"
                    value={formData.dateOccurred}
                    onChange={(e) => handleInputChange("dateOccurred", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="time-occurred">Time Occurred</Label>
                  <Input
                    id="time-occurred"
                    type="time"
                    value={formData.timeOccurred}
                    onChange={(e) => handleInputChange("timeOccurred", e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Detailed Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Describe what happened, including sequence of events, conditions present, and any contributing factors..."
                  className="min-h-32"
                  value={formData.description}
                  onChange={(e) => handleInputChange("description", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="immediate-actions">Immediate Actions Taken</Label>
                <Textarea
                  id="immediate-actions"
                  placeholder="Describe any immediate actions taken to address the incident..."
                  value={formData.immediateActions}
                  onChange={(e) => handleInputChange("immediateActions", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="potential-impact">Potential Impact/Consequences</Label>
                <Textarea
                  id="potential-impact"
                  placeholder="Describe potential or actual impacts (injuries, damage, environmental effects, etc.)..."
                  value={formData.potentialImpact}
                  onChange={(e) => handleInputChange("potentialImpact", e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Reporter Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="h-5 w-5 mr-2" />
                Reporter Information
              </CardTitle>
              <CardDescription>Contact details of the person reporting this incident</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="reporter-name">Full Name *</Label>
                  <Input
                    id="reporter-name"
                    placeholder="Your full name"
                    value={formData.reporterName}
                    onChange={(e) => handleInputChange("reporterName", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reporter-email">Email Address *</Label>
                  <Input
                    id="reporter-email"
                    type="email"
                    placeholder="your.email@company.com"
                    value={formData.reporterEmail}
                    onChange={(e) => handleInputChange("reporterEmail", e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="reporter-phone">Phone Number</Label>
                <Input
                  id="reporter-phone"
                  type="tel"
                  placeholder="Your contact number"
                  value={formData.reporterPhone}
                  onChange={(e) => handleInputChange("reporterPhone", e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Witnesses */}
          <Card>
            <CardHeader>
              <CardTitle>Witnesses</CardTitle>
              <CardDescription>Information about any witnesses to the incident</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="witnesses-present"
                  checked={formData.witnessesPresent}
                  onCheckedChange={(checked) => handleInputChange("witnessesPresent", checked)}
                />
                <Label htmlFor="witnesses-present">There were witnesses present</Label>
              </div>

              {formData.witnessesPresent && (
                <div className="space-y-2">
                  <Label htmlFor="witness-details">Witness Details</Label>
                  <Textarea
                    id="witness-details"
                    placeholder="Names, contact information, and brief description of what witnesses observed..."
                    value={formData.witnessDetails}
                    onChange={(e) => handleInputChange("witnessDetails", e.target.value)}
                  />
                </div>
              )}
            </CardContent>
          </Card>

          {/* File Attachments */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Upload className="h-5 w-5 mr-2" />
                Supporting Documentation
              </CardTitle>
              <CardDescription>Upload photos, documents, or other evidence related to the incident</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                <Label htmlFor="file-upload" className="cursor-pointer">
                  <span className="text-blue-600 hover:text-blue-500">Click to upload files</span>
                  <span className="text-gray-500"> or drag and drop</span>
                </Label>
                <Input
                  id="file-upload"
                  type="file"
                  multiple
                  className="hidden"
                  onChange={handleFileUpload}
                  accept=".jpg,.jpeg,.png,.pdf,.doc,.docx"
                />
                <p className="text-xs text-gray-500 mt-1">PNG, JPG, PDF, DOC up to 10MB each</p>
              </div>

              {formData.attachments.length > 0 && (
                <div className="space-y-2">
                  <Label>Uploaded Files:</Label>
                  {formData.attachments.map((file, index) => (
                    <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                      <span className="text-sm">{file.name}</span>
                      <Button type="button" variant="ghost" size="sm" onClick={() => removeFile(index)}>
                        Remove
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Important Notice */}
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Important:</strong> This report will be reviewed by the safety team and appropriate actions will
              be taken. For immediate emergencies, contact security at ext. 911 or emergency services at 911.
            </AlertDescription>
          </Alert>

          {/* Submit Button */}
          <div className="flex justify-end space-x-4">
            <Button type="button" variant="outline">
              Save as Draft
            </Button>
            <Button type="submit" className="bg-red-600 hover:bg-red-700">
              Submit Incident Report
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
