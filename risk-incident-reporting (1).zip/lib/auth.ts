export interface User {
  id: string
  name: string
  email: string
  role: "staff" | "risk_compliance" | "risk_owner"
  department: string
  permissions: string[]
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
}

export interface RiskIncident {
  id: string
  title: string
  description: string
  category: string
  severity: "critical" | "high" | "medium" | "low"
  status: "open" | "investigating" | "resolved" | "closed"
  reportedBy: string
  reportedDate: string
  location: string
  department: string
  riskOwner?: string
  riskScore: number
  likelihood: number
  impact: number
  comments: Comment[]
  attachments: string[]
}

export interface Comment {
  id: string
  userId: string
  userName: string
  content: string
  timestamp: string
}

// Mock authentication - replace with real auth system
export const mockUsers: User[] = [
  {
    id: "1",
    name: "John Doe",
    email: "john.doe@airtel.com",
    role: "staff",
    department: "Airtel Money Operations",
    permissions: ["create_incident", "view_own_incidents"],
  },
  {
    id: "2",
    name: "Jane Smith",
    email: "jane.smith@airtel.com",
    role: "risk_compliance",
    department: "Risk & Compliance",
    permissions: [
      "create_incident",
      "view_all_incidents",
      "manage_parameters",
      "generate_reports",
      "comment_incidents",
    ],
  },
  {
    id: "3",
    name: "Mike Johnson",
    email: "mike.johnson@airtel.com",
    role: "risk_owner",
    department: "Technology",
    permissions: ["view_owned_risks", "comment_risks", "generate_risk_reports"],
  },
]

export const authenticate = (email: string, password: string): User | null => {
  // Mock authentication - replace with real authentication
  const user = mockUsers.find((u) => u.email === email)
  return user || null
}
