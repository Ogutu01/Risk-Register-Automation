export interface RiskIncident {
  id: string
  title: string
  description: string
  category: string
  severity: "critical" | "high" | "medium" | "low"
  status: "open" | "investigating" | "resolved" | "closed"
  reportedBy: string
  reportedDate: string
  location: string
  department: string
  riskOwner?: string
  riskScore: number
  likelihood: number
  impact: number
  comments: Comment[]
  attachments: string[]
}

export interface Comment {
  id: string
  userId: string
  userName: string
  content: string
  timestamp: string
}

export interface RiskParameter {
  id: string
  name: string
  type: "category" | "severity" | "department"
  values: string[]
  createdBy: string
  createdDate: string
}

export interface DashboardMetrics {
  totalIncidents: number
  openIncidents: number
  criticalIncidents: number
  resolvedThisMonth: number
  averageResolutionTime: number
  riskTrends: { month: string; incidents: number }[]
  severityDistribution: { severity: string; count: number }[]
  departmentBreakdown: { department: string; count: number }[]
}
