"use client"

import { useState } from "react"
import { LoginForm } from "../components/auth/login-form"
import { Sidebar } from "../components/layout/sidebar"
import { Dashboard } from "../components/dashboard/dashboard"
import { IncidentForm } from "../components/incidents/incident-form"
import { IncidentList } from "../components/incidents/incident-list"
import type { User } from "../lib/auth"

export default function RiskRegisterApp() {
  const [user, setUser] = useState<User | null>(null)
  const [currentPage, setCurrentPage] = useState("dashboard")

  const handleLogin = (userData: User) => {
    setUser(userData)
  }

  const handleLogout = () => {
    setUser(null)
    setCurrentPage("dashboard")
  }

  const handleIncidentSubmit = (data: any) => {
    console.log("Incident submitted:", data)
    // Handle incident submission
    alert("Risk incident reported successfully!")
    setCurrentPage("incidents")
  }

  if (!user) {
    return <LoginForm onLogin={handleLogin} />
  }

  const renderCurrentPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <Dashboard user={user} />
      case "report-incident":
        return <IncidentForm user={user} onSubmit={handleIncidentSubmit} />
      case "incidents":
        return <IncidentList user={user} />
      case "risk-parameters":
        return (
          <div className="p-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Risk Parameters</h1>
            <p className="text-gray-600">Manage risk categories, severity levels, and assessment criteria.</p>
            <div className="mt-8 text-center text-gray-500">Risk Parameters management interface coming soon...</div>
          </div>
        )
      case "reports":
        return (
          <div className="p-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Reports</h1>
            <p className="text-gray-600">Generate and export risk management reports.</p>
            <div className="mt-8 text-center text-gray-500">Reports generation interface coming soon...</div>
          </div>
        )
      case "users":
        return (
          <div className="p-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">User Management</h1>
            <p className="text-gray-600">Manage user accounts and permissions.</p>
            <div className="mt-8 text-center text-gray-500">User management interface coming soon...</div>
          </div>
        )
      default:
        return <Dashboard user={user} />
    }
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar user={user} currentPage={currentPage} onPageChange={setCurrentPage} onLogout={handleLogout} />
      <main className="flex-1 overflow-y-auto">{renderCurrentPage()}</main>
    </div>
  )
}
